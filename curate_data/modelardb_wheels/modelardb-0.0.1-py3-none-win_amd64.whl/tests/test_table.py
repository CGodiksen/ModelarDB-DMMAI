# Copyright 2025 The ModelarDB Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import unittest

from modelardb import TimeSeriesTable, AbsoluteErrorBound

from .test_operations import time_series_table_query_schema


class TestTable(unittest.TestCase):
    def test_cannot_specify_error_bound_for_missing_columns(self):
        schema = time_series_table_query_schema()
        field_name = "field_that_does_not_exist"

        with self.assertRaises(ValueError) as context:
            TimeSeriesTable(schema, {field_name: AbsoluteErrorBound(1)})

        self.assertEqual(f"The column {field_name} does not exist.", str(context.exception))

    def test_cannot_specify_generated_column_for_missing_columns(self):
        schema = time_series_table_query_schema()
        field_name = "field_that_does_not_exist"

        with self.assertRaises(ValueError) as context:
            TimeSeriesTable(schema, {}, {field_name: "field_one + field_two"})

        self.assertEqual(f"The column {field_name} does not exist.", str(context.exception))
